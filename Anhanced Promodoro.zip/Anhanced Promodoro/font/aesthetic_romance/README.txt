Hello,
Thank for downloading our product.

NOTE:
By installing or using this font, you are agree to the Product Usage Agreement:

- This demo font is ONLY for PERSONAL USE. NO COMMERCIAL USE ALLOWED!
- Here is the link to purchase full version and commercial license: 
	Myfonts >>> https://www.myfonts.com/collections/sign-studio-foundry
	Creative Market >>> https://creativemarket.com/Sign_Studio
	Font Bundles >>> https://fontbundles.net/sign-std
	Creative Fabrica >>> https://www.creativefabrica.com/designer/sign-studios/
	Envato Element >>> https://elements.envato.com/user/Sign_Std

- If you need a custom license please contact us at >>> myprinces.da@gmail.com

And sometimes I feel very sleepy while making fonts.
If you want to give me a cup of coffee, please here: https://paypal.me/sugi6991?country.x=ID&locale.x=id_ID

Thank you.